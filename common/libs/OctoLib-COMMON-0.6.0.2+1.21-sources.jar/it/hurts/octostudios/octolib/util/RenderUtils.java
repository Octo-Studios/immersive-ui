package it.hurts.octostudios.octolib.util;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;

import java.awt.geom.Point2D;
import net.minecraft.class_241;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import net.minecraft.class_757;

public class RenderUtils {
    public static class_241 toScreenCoords(Matrix4f matrix, double x, double y) {
        Matrix4f inverse = new Matrix4f(matrix);
        inverse.invert();
        return toViewportCoords(inverse, x, y);
    }

    public static class_241 toViewportCoords(Matrix4f matrix, double x, double y) {
        Vector4f vec = new Vector4f((float) x, (float) y, 0.0f, 1.0f);
        vec = matrix.transform(vec);
        return new class_241(vec.x(), vec.y());
    }

    private boolean isPointInQuad(double x, double y, Point2D[] quad) {
        // we divide the quad into two triangles and check if the point is in either one
        return pointInTriangle(x, y, quad[0], quad[1], quad[2]) ||
                pointInTriangle(x, y, quad[0], quad[2], quad[3]);
    }

    private boolean pointInTriangle(double px, double py, Point2D a, Point2D b, Point2D c) {
        double area = 0.5 * (-b.getY() * c.getX() + a.getY() * (-b.getX() + c.getX()) +
                a.getX() * (b.getY() - c.getY()) + b.getX() * c.getY());

        double sign = area < 0 ? -1 : 1;

        double s = (a.getY() * c.getX() - a.getX() * c.getY() + (c.getY() - a.getY()) * px + (a.getX() - c.getX()) * py) * sign;
        double t = (a.getX() * b.getY() - a.getY() * b.getX() + (a.getY() - b.getY()) * px + (b.getX() - a.getX()) * py) * sign;

        return s >= 0 && t >= 0 && (s + t) <= 2 * area * sign;
    }

    public static void renderTextureFromCenter(class_4587 matrix, float centerX, float centerY, float width, float height, float scale, float zOffset) {
        renderTextureFromCenter(matrix, centerX, centerY, 0, 0, width, height, width, height, scale, zOffset);
    }

    public static void renderTextureFromCenter(class_4587 matrix, float centerX, float centerY, float texOffX, float texOffY, float texWidth, float texHeight, float width,
                                               float height, float scale, float zOffset) {
        class_287 builder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);

        RenderSystem.setShader(class_757::method_34542);

        matrix.method_22903();

        matrix.method_46416(centerX, centerY, 0);
        matrix.method_22905(scale, scale, scale);

        Matrix4f m = matrix.method_23760().method_23761();

        float u1 = texOffX / texWidth;
        float u2 = (texOffX + width) / texWidth;
        float v1 = texOffY / texHeight;
        float v2 = (texOffY + height) / texHeight;

        float w2 = width / 2F;
        float h2 = height / 2F;

        builder.method_22918(m, -w2, +h2, zOffset).method_22913(u1, v2);
        builder.method_22918(m, +w2, +h2, zOffset).method_22913(u2, v2);
        builder.method_22918(m, +w2, -h2, zOffset).method_22913(u2, v1);
        builder.method_22918(m, -w2, -h2, zOffset).method_22913(u1, v1);

        matrix.method_22909();

        class_286.method_43433(builder.method_60800());
    }

    public static void renderTilingTexture(class_4587 matrix, float x, float y, float texOffX, float texOffY,
                                           float texWidth, float texHeight, float width, float height,
                                           float zOffset, boolean tileHorizontally, boolean tileVertically) {
        RenderSystem.setShader(class_757::method_34542);

        int wrapS = tileHorizontally ? GL11.GL_REPEAT : GL11.GL_CLAMP;
        int wrapT = tileVertically ? GL11.GL_REPEAT : GL11.GL_CLAMP;
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, wrapS);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, wrapT);

        float uStart = texOffX / texWidth;
        float vStart = texOffY / texHeight;
        float uRange = tileHorizontally ? (width / texWidth) : 1.0f;
        float vRange = tileVertically ? (height / texHeight) : 1.0f;
        float uEnd = uStart + uRange;
        float vEnd = vStart + vRange;

        class_287 builder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);

        matrix.method_22903();
        matrix.method_46416(x, y, 0);
        Matrix4f m = matrix.method_23760().method_23761();

        builder.method_22918(m, 0f, height, zOffset).method_22913(uStart, vEnd)
                .method_22918(m, width, height, zOffset).method_22913(uEnd, vEnd)
                .method_22918(m, width, 0f, zOffset).method_22913(uEnd, vStart)
                .method_22918(m, 0f, 0f, zOffset).method_22913(uStart, vStart);

        matrix.method_22909();
        class_286.method_43433(builder.method_60800());
    }
}
