package it.hurts.octostudios.octolib.util;

import net.minecraft.class_332;

public class CommonCode {
    public static void applyShake(class_332 guiGraphics, float partialTick) {

    }
}
