package it.hurts.octostudios.octolib.module.particle.trail;

import it.hurts.octostudios.octolib.module.particle.RenderBuffer;
import net.minecraft.class_243;
import net.minecraft.class_310;

public interface TrailBuffer extends Iterable<class_243>, RenderBuffer<TrailProvider, TrailBuffer> {
    
    void write(class_243 vec3);
    
    int size();
    
    void remove();
    
    @Override
    default void tick(TrailProvider provider) {
        var position = provider.getTrailPosition(class_310.method_1551().method_60646().method_60636());
        
        if (provider.isTrailAlive() && provider.isTrailGrowing()) {
            write(position);
        } else if (size() > 0)
            remove();
    }
    
}
