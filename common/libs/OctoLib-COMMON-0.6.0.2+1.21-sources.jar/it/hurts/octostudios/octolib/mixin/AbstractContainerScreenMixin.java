package it.hurts.octostudios.octolib.mixin;

import it.hurts.octostudios.octolib.client.particle.ParticleSystem;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public class AbstractContainerScreenMixin {
    @Shadow protected int leftPos;

    @Shadow protected int topPos;

    @Inject(method = "render", at = @At("RETURN"))
    private void renderParticles(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(leftPos, topPos, 0);
        ParticleSystem.renderScreenParticles((class_437) (Object) this, guiGraphics, class_310.method_1551().method_60646().method_60637(false));
        guiGraphics.method_51448().method_22909();
    }
}
