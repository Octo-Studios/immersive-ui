package it.hurts.octostudios.octolib.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import it.hurts.octostudios.octolib.client.particle.ParticleSystem;
import it.hurts.octostudios.octolib.client.shake.Shakeable;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.joml.Vector2f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_437.class)
public class ScreenMixin {
    @Inject(method = "render", at = @At("RETURN"))
    private void beforeRender(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        class_437 screen = (class_437) (Object) this;
        if (screen instanceof class_465<?>) {
            return;
        }

        ParticleSystem.renderScreenParticles(screen, guiGraphics, class_310.method_1551().method_61966().method_60637(false));
    }
}
