package it.hurts.octostudios.octolib.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_332.class)
public interface GuiGraphicsAccessor {
    @Invoker("innerBlit")
    void innerBlitAccessor(RenderPipeline pipeline, class_2960 atlas, int x0, int x1, int y0, int y1, float u0, float u1, float v0, float v1, int color);
}
