package it.hurts.octostudios.octolib.mixin;

import it.hurts.octostudios.octolib.client.particle.ParticleSystem;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class GuiMixin {
    @Inject(method = "render", at = @At("RETURN"))
    private void renderGuiParticles(class_332 guiGraphics, class_9779 deltaTracker, CallbackInfo ci) {
        ParticleSystem.renderGuiParticles(guiGraphics, deltaTracker.method_60637(true));
    }
}
