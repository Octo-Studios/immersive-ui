package it.hurts.octostudios.octolib.mixin;

import it.hurts.octostudios.octolib.module.particle.OctoRenderManager;
import it.hurts.octostudios.octolib.module.particle.trail.EntityTrailProvider;
import it.hurts.octostudios.octolib.module.particle.trail.EntityTrailRegistry;
import net.minecraft.class_1297;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_638.class)
public class ClientLevelMixin {
    @Inject(method = "addEntity", at = @At("TAIL"))
    private void injectTrail(class_1297 entity, CallbackInfo ci) {
        EntityTrailProvider<class_1297> trail = EntityTrailRegistry.getTrailProvider(entity);
        if (trail != null) {
            OctoRenderManager.registerProvider(trail);
        }
    }
}
