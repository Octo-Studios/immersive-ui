package it.hurts.octostudios.octolib.client.screen.widget;

import it.hurts.octostudios.octolib.client.animation.Tween;
import it.hurts.octostudios.octolib.client.animation.easing.EaseType;
import it.hurts.octostudios.octolib.client.animation.easing.TransitionType;
import lombok.Setter;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_4069;
import net.minecraft.class_6382;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2f;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

public class TestGear extends class_339 implements HasRenderMatrix, class_4069 {
    private Matrix3x2f renderMatrix;
    Tween tween = Tween.create();

    @Setter
    private float rot;

    List<class_364> children = new ArrayList<>();

    public TestGear(int x, int y) {
        super(x, y, 128, 128, class_2561.method_43473());
        this.children.add(new TestPin(16, 16, this));
    }

    @Override
    public Matrix3x2f getMatrix() {
        return this.renderMatrix;
    }

    @Override
    public void setMatrix(Matrix3x2f matrix) {
        this.renderMatrix = matrix;
    }

    @Override
    protected void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(this.method_46426() + this.field_22758/2f, this.method_46427() + this.field_22759/2f);
        guiGraphics.method_51448().rotate((float) Math.toRadians(rot));
        guiGraphics.method_51448().translate(-this.field_22758/2f - this.method_46426(), -this.field_22759/2f - this.method_46427());
        this.setMatrix(new Matrix3x2f(guiGraphics.method_51448()));

        guiGraphics.method_49601(this.method_46426(), this.method_46427(), this.field_22758, this.field_22759, 0xffffffff);
        this.method_25396().forEach(child -> {
            if (child instanceof class_4068 renderable) {
                renderable.method_25394(guiGraphics, mouseX, mouseY, partialTick);
            }
        });

        guiGraphics.method_51448().popMatrix();
    }

    @Override
    protected void method_47399(class_6382 narrationElementOutput) {

    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        boolean result = super.method_25402(mouseX,mouseY, button);
        if (!class_4069.super.method_25402(mouseX, mouseY, button) && result) {
            tween.kill();
            tween = Tween.create();
            tween.tweenMethod(this::setRot, this.rot, this.rot + 60f, 0.75f).setEaseType(EaseType.EASE_OUT).setTransitionType(TransitionType.QUART);
            tween.start();
            return true;
        };
        return false;
    }

    @Override
    public List<? extends class_364> method_25396() {
        return children;
    }

    @Override
    public boolean method_25397() {
        return false;
    }

    @Override
    public void method_25398(boolean isDragging) {

    }

    @Override
    public @Nullable class_364 method_25399() {
        return null;
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {

    }
}
