package it.hurts.octostudios.octolib.client.screen.widget;

import it.hurts.octostudios.octolib.mixin.AbstractWidgetAccessor;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_8021;
import net.minecraft.class_8030;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector2i;

public interface Child<T extends class_8021> extends class_8021, class_364 {
    @Nullable T getParent();
    void setParent(@Nullable T parent);

    default int getLocalX() {
        if (this instanceof class_339 widget) {
            return ((AbstractWidgetAccessor) widget).getLocalX();
        }

        return 0;
    }

    default int getLocalY() {
        if (this instanceof class_339 widget) {
            return ((AbstractWidgetAccessor) widget).getLocalY();
        }

        return 0;
    }

    default Vector2i getLocalPosition() {
        return new Vector2i(getLocalX(), getLocalY());
    }

    default Vector2i getParentPosition() {
        T parent = getParent();
        return parent != null ? new Vector2i(parent.method_46426(), parent.method_46427()) : new Vector2i(0, 0);
    }

    default Vector2i getPosition() {
        Vector2i parentPos = getParentPosition();
        return new Vector2i(getLocalX() + parentPos.x, getLocalY() + parentPos.y);
    }

    @Override
    default @NotNull class_8030 method_48202() {
        return class_8021.super.method_48202();
    }

    default void detachWidget() {
        Vector2i globalPos = getPosition();
        setParent(null);
        method_48229(globalPos.x, globalPos.y);
    }

    default void attachWidget(@Nullable T parent) {
        Vector2i globalPos = getPosition();
        setParent(parent);
        Vector2i parentPos = getParentPosition();
        method_48229(globalPos.x - parentPos.x, globalPos.y - parentPos.y);
    }
}