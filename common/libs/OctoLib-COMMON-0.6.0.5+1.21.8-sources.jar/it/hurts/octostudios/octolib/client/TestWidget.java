package it.hurts.octostudios.octolib.client;

import it.hurts.octostudios.octolib.client.animation.easing.EaseType;
import it.hurts.octostudios.octolib.client.animation.easing.TransitionType;
import it.hurts.octostudios.octolib.client.animation.Tween;
import it.hurts.octostudios.octolib.client.particle.GalacticUIParticle;
import it.hurts.octostudios.octolib.client.particle.UIParticle;
import it.hurts.octostudios.octolib.util.OctoColor;
import lombok.Setter;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_437;
import net.minecraft.class_6382;
import org.joml.Matrix3x2f;
import org.joml.Matrix4f;
import org.joml.Vector2f;

public class TestWidget extends class_339 {
    protected class_437 screen;
    private Vector2f position = new Vector2f();
    private Vector2f scale = new Vector2f(1, 1);
    @Setter
    private OctoColor color = new OctoColor(1f,1f,1f,1f);

    public TransitionType transitionType;
    public EaseType easeType;
    public Tween tween;

    private Matrix3x2f renderPose = new Matrix3x2f();

    public Tween hoverTween;
    private boolean hasHovered = false;

    public TestWidget(int x, int y, TransitionType transitionType, EaseType easeType, class_437 screen) {
        super(x, y, 8, 8, class_2561.method_43470(easeType.name() + "_" + transitionType.name()));
        this.transitionType = transitionType;
        this.easeType = easeType;
        this.screen = screen;
    }

    @Override
    protected void method_48579(class_332 guiGraphics, int i, int j, float partialTick) {
        float actualPartialTick = class_310.method_1551().method_61966().method_60637(false);

        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(position.x + this.method_46426(), position.y + this.method_46427());

        guiGraphics.method_51448().translate(this.field_22758/2f, this.field_22759/2f);
        guiGraphics.method_51448().scale(scale.x, scale.y);
        guiGraphics.method_51448().translate(-this.field_22758/2f, -this.field_22759/2f);

        this.renderPose = new Matrix3x2f(guiGraphics.method_51448());
        guiGraphics.method_49601(0, 0, this.method_25368(), this.method_25364(), color.getARGB());
        guiGraphics.method_51448().popMatrix();

        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(this.method_46426(), this.method_46427());
        guiGraphics.method_49601(-2, -12, 112, this.method_25364() + 14, 0x50ffffff);
        guiGraphics.method_51448().scale(0.75f, 1);
        guiGraphics.method_51439(class_310.method_1551().field_1772, this.method_25369(), 0, -10, 0x50ffffff, true);
        guiGraphics.method_51448().popMatrix();
    }

    @Override
    protected void method_47399(class_6382 narrationElementOutput) {

    }

    @Override
    public boolean method_49606() {
        boolean hovered = super.method_49606();

        if (hovered && !hasHovered) {
            hasHovered = true;
            if (hoverTween != null) {
                hoverTween.kill();
            }

            hoverTween = Tween.create().setTransitionType(TransitionType.QUART).setEase(EaseType.EASE_OUT);
            hoverTween.tweenProperty(this, "scale", new Vector2f(1.25f, 1.25f), 0.2);
        } else if (!hovered && hasHovered) {
            hasHovered = false;
            if (hoverTween != null) {
                hoverTween.kill();
            }

            hoverTween = Tween.create().setTransitionType(TransitionType.QUART).setEase(EaseType.EASE_OUT);
            hoverTween.tweenProperty(this, "scale", new Vector2f(1f, 1f), 0.2);
        }

        return hovered;
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        if (tween != null) {
            tween.kill();
        }

        Runnable spawnParticle = () -> {
            UIParticle uiParticle = new GalacticUIParticle(20f, 1, this.method_46426() + position.x, this.method_46427() + position.y, UIParticle.Layer.SCREEN, 1f);
            uiParticle.setScreen(screen);
            uiParticle.instantiate();
        };

        tween = Tween.create().setTransitionType(transitionType).setEase(easeType).setLoops(3);
//        tween.tweenProperty(this, "position", new Vector2f(), 0);
//        tween.tweenProperty(this.position, "x", 100f, 0.5);
//        tween.tweenRunnable(() -> OctoLib.LOGGER.info("First runnable!"));
//        tween.tweenProperty(this.position, "y", 20f, 0.5);
//        tween.tweenRunnable(() -> OctoLib.LOGGER.info("Waiting for a second after this one..."));
//        tween.tweenInterval(1);
//        tween.tweenRunnable(() -> OctoLib.LOGGER.info("Yippie!"));
//        tween.tweenProperty(this, "color", Color.WHITE, 1)
//                .from(Color.GREEN)
//                .setTransitionType(TransitionType.LINEAR);

        tween.tweenMethod(this::setColor, OctoColor.GREEN, OctoColor.WHITE, 0.5).setTransitionType(TransitionType.LINEAR);
        tween.parallel().tweenProperty(this, "position", new Vector2f(10, 10), 0.5);
        tween.parallel().tweenRunnable(spawnParticle);
        tween.tweenInterval(0.5);
        tween.tweenMethod(this::setColor, OctoColor.RED, OctoColor.WHITE, 0.5).setTransitionType(TransitionType.LINEAR);
        tween.parallel().tweenProperty(this, "position", new Vector2f(0, 0), 0.5);
        tween.parallel().tweenRunnable(spawnParticle);
        tween.tweenInterval(0.5);

        super.method_25348(mouseX, mouseY);
    }
}
