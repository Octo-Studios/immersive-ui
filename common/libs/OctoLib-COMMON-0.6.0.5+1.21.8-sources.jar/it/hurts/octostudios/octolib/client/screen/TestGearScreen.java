package it.hurts.octostudios.octolib.client.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import it.hurts.octostudios.octolib.client.animation.Tween;
import it.hurts.octostudios.octolib.client.particle.GalacticUIParticle;
import it.hurts.octostudios.octolib.client.particle.UIParticle;
import it.hurts.octostudios.octolib.client.screen.widget.TestGear;
import it.hurts.octostudios.octolib.util.RenderUtils;
import java.util.Random;
import net.minecraft.class_1109;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_437;

import static net.minecraft.class_10799.field_56883;

public class TestGearScreen extends class_437 {
    Tween tween = Tween.create().setLoops(-1);

    public TestGearScreen() {
        super(class_2561.method_43473());

        tween.tweenRunnable(() -> class_310.method_1551().method_1483().method_4873(class_1109.method_4758(class_3417.field_14699, 2F)));
        tween.tweenInterval(0.5);
        tween.tweenRunnable(() -> class_310.method_1551().method_1483().method_4873(class_1109.method_4758(class_3417.field_15105, 1.6F)));
        tween.tweenInterval(0.5);
        tween.tweenRunnable(() -> class_310.method_1551().method_1483().method_4873(class_1109.method_4758(class_3417.field_15105, 1.6F)));
        tween.tweenInterval(0.5);
        tween.tweenRunnable(() -> class_310.method_1551().method_1483().method_4873(class_1109.method_4758(class_3417.field_15105, 1.6F)));
        tween.tweenInterval(0.5);
        tween.start();
    }

    boolean shouldTick;

    @Override
    public void method_25393() {
        super.method_25393();
        if (class_310.method_1551().field_1724.field_6012 % 20 == 0) this.shouldTick = true;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.method_37063(new TestGear((int) (this.field_22789/2f-64), (int) (this.field_22790/2f-64)));
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        //super.renderBackground(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        if (shouldTick) {
            this.shouldTick = false;
            UIParticle particle = new GalacticUIParticle(1.25f, 40, mouseX, mouseY, UIParticle.Layer.SCREEN, 0);
            particle.setScreen(this);
            particle.setRollVelocity(new Random().nextFloat(-5, 5));
            particle.instantiate();
        }

        RenderUtils.renderTilingTexture(field_56883, class_2960.method_60656("textures/particle/sga_").method_48331("a.png"), guiGraphics, 10, 10, 0, 0, 8, 8, 80, 80, 0xffffffff, true, false);
    }

    @Override
    public void method_25419() {
        super.method_25419();
        if (tween != null) {
            tween.kill();
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
