package it.hurts.octostudios.octolib.client.particle;

import java.nio.charset.MalformedInputException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class ParticleSystem {
    protected static List<UIParticle> GUI_PARTICLES = new ArrayList<>();
    protected static Map<class_437, List<UIParticle>> SCREEN_PARTICLES = new WeakHashMap<>();

    public static void tick() {
        GUI_PARTICLES.forEach(UIParticle::tick);
        SCREEN_PARTICLES.values().forEach(uiParticles -> uiParticles.forEach(UIParticle::tick));

        GUI_PARTICLES.removeIf(UIParticle::isExpired);
        SCREEN_PARTICLES.values().forEach(uiParticles -> uiParticles.removeIf(UIParticle::isExpired));
        SCREEN_PARTICLES.values().removeIf(List::isEmpty);
    }

    public static void renderScreenParticles(class_437 screen, class_332 guiGraphics, float partialTicks) {
        if (SCREEN_PARTICLES.containsKey(screen)) {
            SCREEN_PARTICLES.get(screen).forEach(uiParticle -> uiParticle.render(guiGraphics, partialTicks));
        }
    }

    public static void renderGuiParticles(class_332 guiGraphics, float partialTicks) {
        GUI_PARTICLES.forEach(uiParticle -> uiParticle.render(guiGraphics, partialTicks));
    }
}
