package it.hurts.octostudios.octolib.client;

import it.hurts.octostudios.octolib.client.animation.Tween;
import it.hurts.octostudios.octolib.client.animation.easing.EaseType;
import it.hurts.octostudios.octolib.client.animation.easing.TransitionType;
import it.hurts.octostudios.octolib.client.particle.GalacticUIParticle;
import it.hurts.octostudios.octolib.client.particle.UIParticle;
import org.joml.Vector2d;

import java.util.function.Predicate;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_437;

public class TestScreen extends class_437 {
    private int ticker;
    private boolean down;

    public Vector2d squeeze = new Vector2d(1,1);

    public TestScreen() {
        super(class_2561.method_43473());
    }

    @Override
    protected void method_25426() {
        int x = 8;
        int y = 16;
        for (TransitionType transitionType : TransitionType.values()) {
            for (EaseType easeType : EaseType.values()) {
                this.method_37063(new TestWidget(x, y, transitionType, easeType, this));
                y += 30;

                if (y + 30 > this.field_22790) {
                    x += 120;
                    y = 16;
                }
            }
        }
    }

    @Override
    public void method_25393() {
        super.method_25393();
    }

    @Override
    public void method_25394(class_332 guiGraphics, int i, int j, float f) {
        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(this.field_22789/2f, this.field_22790/2f);
        guiGraphics.method_51448().scale((float) this.squeeze.x, (float) this.squeeze.y);
        guiGraphics.method_51448().translate(-this.field_22789/2f, -this.field_22790/2f);

        UIParticle uiParticle = new GalacticUIParticle(20f, 2, i, j, UIParticle.Layer.SCREEN, 1f);
        uiParticle.setScreen(this);
        uiParticle.instantiate();

        super.method_25394(guiGraphics, i, j, f);
        guiGraphics.method_51433(
                class_310.method_1551().field_1772,
                String.valueOf(ticker),
                this.field_22789 - class_310.method_1551().field_1772.method_1727(String.valueOf(ticker)) - 4,
                4, 0xffffffff, true);
        guiGraphics.method_51433(
                class_310.method_1551().field_1772,
                String.valueOf(f),
                this.field_22789 - class_310.method_1551().field_1772.method_1727(String.valueOf(f)) - 4,
                this.field_22790 - 10, 0x33ffffff, true);

        guiGraphics.method_51448().popMatrix();
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        boolean result = super.method_25402(mouseX, mouseY, button);
        if (!result && button == 1) {
            for (class_364 g : this.method_25396()) {
                if (g instanceof TestWidget widget) {
                    widget.method_25348(mouseX, mouseY);
                }
            }
        } else if (!result && button == 0) {
            //this.squeeze = new Vector2d(1,1);

            var tween = Tween.create().setTransitionType(TransitionType.SINE).setParallel(true);
            tween.tweenProperty(this, "squeeze.y", 0.9, 0.15).setEaseType(EaseType.EASE_OUT);
            tween.tweenProperty(this, "squeeze.x", 0.9, 0.15).setEaseType(EaseType.EASE_IN);
            tween.tweenProperty(this, "squeeze.y", 1, 0.15).setDelay(0.15).setEaseType(EaseType.EASE_OUT);
            tween.tweenProperty(this, "squeeze.x", 1, 0.15).setDelay(0.15).setEaseType(EaseType.EASE_IN);
        }
        return result;
    }

    @Override
    public boolean method_25421() {
        return true;
    }

    @Override
    public void method_25419() {
//        for (GuiEventListener g : this.children()) {
//            if (g instanceof TestWidget widget && widget.animator != null) {
//                widget.animator.stop();
//            }
//        }

        super.method_25419();
    }
}
