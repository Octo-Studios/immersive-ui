package it.hurts.octostudios.octolib.client.screen.widget;

import it.hurts.octostudios.octolib.client.animation.Tween;
import it.hurts.octostudios.octolib.util.OctoColor;
import it.hurts.octostudios.octolib.util.RenderUtils;
import lombok.Setter;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;
import org.jetbrains.annotations.Nullable;

public class TestPin extends class_339 implements Child<TestGear> {
    @Setter
    OctoColor color = OctoColor.GREEN;
    TestGear parent;

    public TestPin(int x, int y, TestGear parent) {
        super(x, y, 24, 24, class_2561.method_43473());
        this.setParent(parent);
        this.method_48229(x, y);
    }

    @Override
    public @Nullable TestGear getParent() {
        return parent;
    }

    @Override
    public void setParent(@Nullable TestGear parent) {
        this.parent = parent;
    }

    @Override
    protected void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (this.method_49606() && this.color == OctoColor.GREEN) {
            this.color = OctoColor.BLUE;
        } else if (!this.method_49606() && this.color == OctoColor.BLUE) {
            this.color = OctoColor.GREEN;
        }

        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(this.method_46426(), this.method_46427());
        guiGraphics.method_49601(0, 0, this.field_22758, this.field_22759, color.getARGB());
        guiGraphics.method_51448().popMatrix();

        if (this.getParent() instanceof HasRenderMatrix has) {
            guiGraphics.method_51448().pushMatrix();
            class_241 bleh = RenderUtils.toScreenCoords(has.getMatrix(), mouseX, mouseY);
            guiGraphics.method_51448().translate((float) (bleh.field_1343-0.5), (float) (bleh.field_1342-0.5));
            guiGraphics.method_49601(0, 0, 2, 2, 0xffff0000);
            guiGraphics.method_51448().popMatrix();
        }
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        super.method_25348(mouseX, mouseY);
        Tween tween = Tween.create();
        tween.tweenMethod(this::setColor, OctoColor.RED, OctoColor.GREEN, 0.5f);
        tween.start();
    }

    @Override
    protected void method_47399(class_6382 narrationElementOutput) {

    }
}
