package it.hurts.octostudios.octolib.module.particle;

import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

public interface RenderProvider<P extends RenderProvider<P, B>, B extends RenderBuffer<P, B>> {
    
    class_243 getRenderPosition(float partialTick);
    
    void render(float pTicks, class_4587 poseStack, class_4588 consumer);
    
    default double getRenderDistance() {
        return 64;
    };
    
    boolean shouldRender(B buffer);
    
    int getUpdateFrequency();
    
    B createBuffer();
    
}
