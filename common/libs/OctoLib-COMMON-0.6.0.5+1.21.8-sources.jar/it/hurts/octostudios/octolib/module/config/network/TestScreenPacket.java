package it.hurts.octostudios.octolib.module.config.network;

import dev.architectury.networking.NetworkManager;
import it.hurts.octostudios.octolib.OctoLib;
import it.hurts.octostudios.octolib.client.screen.TestGearScreen;
import it.hurts.octostudios.octolib.module.network.Packet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class TestScreenPacket extends Packet {
    public static class_9154<TestScreenPacket> TYPE = Packet.createType(OctoLib.MODID, "test_screen");
    public static class_9139<class_9129, TestScreenPacket> STREAM_CODEC = Packet.createCodec(TestScreenPacket::write, TestScreenPacket::new);

    public TestScreenPacket(class_9129 buf) {
        super(buf);
    }

    public TestScreenPacket() {

    }

    @Override
    public void write(class_9129 buf) {

    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    @Environment(EnvType.CLIENT)
    protected void handleClient(NetworkManager.PacketContext packetContext) {
        class_310.method_1551().method_1507(new TestGearScreen());
    }
}
