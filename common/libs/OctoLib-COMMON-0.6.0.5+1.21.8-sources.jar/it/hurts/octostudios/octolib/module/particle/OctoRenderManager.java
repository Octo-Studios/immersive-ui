package it.hurts.octostudios.octolib.module.particle;

import it.hurts.octostudios.octolib.OctoLibClient;
import it.hurts.octostudios.octolib.client.animation.TweenSystem;
import it.hurts.octostudios.octolib.client.particle.ParticleSystem;
import it.hurts.octostudios.octolib.client.shake.ShakeSystem;
import it.hurts.octostudios.octolib.module.config.ConfigManager;
import lombok.Getter;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.apache.logging.log4j.util.Cast;

import java.util.*;

public class OctoRenderManager {

    static long lastTick = 0;
    @Getter
    static Queue<RenderProvider<?, ?>> providers = new ArrayDeque<>();
    static WeakHashMap<RenderProvider<?, ?>, RenderBuffer<?, ?>> map = new WeakHashMap<>();

    public static void worldExit(class_746 player) {
        map.clear();
        providers.clear();
        ConfigManager.reloadAll();
    }

    public static void clientTick(class_638 level) {
        long time = level.method_8510();
        if (time == lastTick) return;
        lastTick = time;

        // 2. process all providers as before
        var iterator = providers.iterator();
        while (iterator.hasNext()) {
            var p = iterator.next();
            RenderBuffer buffer = getOrCreateBuffer(Cast.cast(p));

            if (!p.shouldRender(Cast.cast(buffer))) {
                map.remove(p);
                iterator.remove();
                continue;
            }

            if (time % p.getUpdateFrequency() == 0) {
                buffer.tick(p);
            }
        }
    }

    public static void clientRenderTick() {
        ShakeSystem.updateAll();
    }

    public static <B extends RenderBuffer<P, B>, P extends RenderProvider<P, B>> B getOrCreateBuffer(P provider) {
        if (map.containsKey(provider))
            return (B) map.get(provider);

        var buffer = provider.createBuffer();
        map.put(provider, buffer);
        return buffer;
    }

    public static <B extends RenderBuffer<P, B>, P extends RenderProvider<P, B>> void registerProvider(P provider) {
        if (map.containsKey(provider))
            return;

        providers.add(provider);
        map.put(provider, provider.createBuffer());
    }
}
