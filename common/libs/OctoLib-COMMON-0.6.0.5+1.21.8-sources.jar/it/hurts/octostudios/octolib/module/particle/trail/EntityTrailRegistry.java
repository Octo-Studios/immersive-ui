package it.hurts.octostudios.octolib.module.particle.trail;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1297;
import net.minecraft.class_1299;

public class EntityTrailRegistry {
    public static final Map<class_1299<? extends class_1297>, Function<? extends class_1297, ? extends EntityTrailProvider<? extends class_1297>>> classProviders = new HashMap<>();

    public static <T extends class_1297> void registerProvider(class_1299<T> type, Function<T, EntityTrailProvider<T>> factory) {
        classProviders.put(type, factory);
    }

    public static <T extends class_1297> EntityTrailProvider<T> getTrailProvider(T entity) {
        Function<T, EntityTrailProvider<T>> factory = (Function<T, EntityTrailProvider<T>>) classProviders.get(entity.method_5864());
        if (factory == null) {
            return null;
        }

        return factory.apply(entity);
    }
}
