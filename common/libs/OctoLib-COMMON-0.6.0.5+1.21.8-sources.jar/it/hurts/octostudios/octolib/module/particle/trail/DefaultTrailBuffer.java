package it.hurts.octostudios.octolib.module.particle.trail;

import lombok.Data;
import net.minecraft.class_243;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;

@Data
public class DefaultTrailBuffer<T> implements TrailBuffer {
    private Deque<class_243> points = new ArrayDeque<>();

    private final int maxSize;

    public DefaultTrailBuffer(int maxSize) {
        this.maxSize = maxSize;
    }

    @Override
    public void write(class_243 vec3) {
        if (size() >= maxSize)
            remove();

        points.push(vec3);
    }

    @Override
    public int size() {
        return points.size();
    }

    @Override
    public void remove() {
        points.removeLast();
    }

    @Override
    public @NotNull Iterator<class_243> iterator() {
        return points.iterator();
    }
}
