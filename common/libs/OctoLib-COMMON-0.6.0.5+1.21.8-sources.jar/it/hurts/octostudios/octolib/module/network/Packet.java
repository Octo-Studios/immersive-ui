package it.hurts.octostudios.octolib.module.network;

import dev.architectury.networking.NetworkManager;
import io.netty.buffer.ByteBuf;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9141;
import net.minecraft.class_9143;

public abstract class Packet implements class_8710 {
    protected Packet() {

    }

    public Packet(class_9129 buf) {

    }

    public abstract void write(class_9129 buf);

    public final void handle(NetworkManager.PacketContext packetContext) {
        switch (packetContext.getEnvironment()) {
            case CLIENT -> this.handleClient(packetContext);
            case SERVER -> this.handleServer(packetContext);
        }
    }

    @Environment(EnvType.CLIENT)
    protected void handleClient(NetworkManager.PacketContext packetContext) {

    }

    protected void handleServer(NetworkManager.PacketContext packetContext) {

    }

    public static <T extends Packet> class_9154<T> createType(String namespace, String path) {
        return new class_9154<>(class_2960.method_60655(namespace, path));
    }

    public static <B extends ByteBuf, T extends Packet> class_9139<B, T> createCodec(class_9143<B, T> encoder, class_9141<B, T> decoder) {
        return class_8710.method_56484(encoder, decoder);
    }
}