package it.hurts.octostudios.octolib.module.config.network;

import dev.architectury.networking.NetworkManager;
import it.hurts.octostudios.octolib.OctoLib;
import it.hurts.octostudios.octolib.client.screen.TestGearScreen;
import it.hurts.octostudios.octolib.module.network.Packet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.lang.reflect.InvocationTargetException;

public class UnholyAbominationPacket extends Packet {
    public static final class_9154<UnholyAbominationPacket> TYPE =
            Packet.createType(OctoLib.MODID, "no_just_no");
    public static final class_9139<class_9129, UnholyAbominationPacket> STREAM_CODEC =
            Packet.createCodec(UnholyAbominationPacket::write, UnholyAbominationPacket::new);

    String path;

    public UnholyAbominationPacket(class_9129 buf) {
        this.path = buf.method_19772();
    }

    public UnholyAbominationPacket(String path) {
        this.path = path;
    }

    public void write(class_9129 buf) {
        buf.method_10814(path);
    }

    @Override
    @Environment(EnvType.CLIENT)
    protected void handleClient(NetworkManager.PacketContext packetContext) {
        try {
            Class<?> clazz = Class.forName(path);
            var something = clazz.getConstructor().newInstance();
            if (something instanceof class_437 screen) {
                class_310.method_1551().method_1507(screen);
            } else {
                OctoLib.LOGGER.warn("ok that's not a screen, idk what it is, but not a screen: {}", path);
            }

        } catch (ClassNotFoundException e) {
            OctoLib.LOGGER.warn("No class has been found: {}", path);
        } catch (InvocationTargetException | InstantiationException | IllegalAccessException | NoSuchMethodException e) {
            OctoLib.LOGGER.warn("no: {}", path);
        }
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}

