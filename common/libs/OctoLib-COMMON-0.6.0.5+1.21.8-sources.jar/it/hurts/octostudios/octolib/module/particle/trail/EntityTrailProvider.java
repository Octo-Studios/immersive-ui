package it.hurts.octostudios.octolib.module.particle.trail;

import net.minecraft.class_1297;
import net.minecraft.class_243;

public abstract class EntityTrailProvider<T extends class_1297> extends TrailProvider {
    public T entity;

    public EntityTrailProvider(T entity) {
        this.entity = entity;
    }

    @Override
    public class_243 getTrailPosition(float partialTick) {
        return entity.method_30950(partialTick);
    }

    @Override
    public int getTrailUpdateFrequency() {
        return 0;
    }

    @Override
    public boolean isTrailAlive() {
        return entity.method_5805();
    }

    @Override
    public boolean isTrailGrowing() {
        return entity.field_6012 > 0 && entity.method_18798().method_1033() > 0;
    }
}
