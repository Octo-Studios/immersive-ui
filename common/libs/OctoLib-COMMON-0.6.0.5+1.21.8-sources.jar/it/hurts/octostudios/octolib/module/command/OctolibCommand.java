package it.hurts.octostudios.octolib.module.command;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.architectury.networking.NetworkManager;
import it.hurts.octostudios.octolib.OctoLib;
import it.hurts.octostudios.octolib.module.config.ConfigManager;
import it.hurts.octostudios.octolib.module.config.network.TestScreenPacket;
import it.hurts.octostudios.octolib.module.config.network.UnholyAbominationPacket;
import java.lang.reflect.InvocationTargetException;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_7157;

public class OctolibCommand {
    
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 buildContext, class_2170.class_5364 commandSelection) {
        dispatcher.register(class_2170.method_9247("octolib").requires(s -> s.method_9259(2))
                        .then(class_2170.method_9247("openScreen")
                                .then(class_2170.method_9244("classpath", StringArgumentType.string())
                                        .executes(context -> {
                                            String path = StringArgumentType.getString(context, "classpath");
                                            NetworkManager.sendToPlayer(context.getSource().method_44023(), new UnholyAbominationPacket(path));
                                            return Command.SINGLE_SUCCESS;
                                        })
                                )
                        )
                .then(class_2170.method_9247("animatorSystemTestScreen")
                        .executes(component -> {
                            if (component.getSource().method_44023() == null) {
                                component.getSource().method_9213(class_2561.method_43470("This command should be ran by a player.").method_27692(class_124.field_1061));
                            }

                            NetworkManager.sendToPlayer(component.getSource().method_44023(), new TestScreenPacket());
                            return Command.SINGLE_SUCCESS;
                        }))
                .then(class_2170.method_9247("config")
                        .then(class_2170.method_9247("reload")
                                .then(class_2170.method_9247("all")
                                        .executes(conComponent -> {
                                            int counter = 0;
                                            boolean isAdmin = conComponent.getSource().method_9259(4);
                                            
                                            for (var path : ConfigManager.getAllPaths()) {
                                                try {
                                                    if (ConfigManager.isServerConfig(path)) {
                                                        if (isAdmin) {
                                                            ConfigManager.reload(path);
                                                            ConfigManager.syncConfig(path, conComponent.getSource().method_9211());
                                                        } else
                                                            conComponent.getSource().method_9213(
                                                                    class_2561.method_43470("You have not permission to reload config."));
                                                    } else {
                                                        ConfigManager.reload(path);
                                                    }
                                                    counter++;
                                                } catch (RuntimeException e) {
                                                    e.printStackTrace();
                                                    conComponent.getSource().method_9213(class_2561.method_43470("Error occurs while reload config by path ")
                                                            .method_10852(class_2561.method_43470("\"" + path + "\"")));
                                                    
                                                    return 0;
                                                }
                                            }
    
                                            conComponent.getSource().method_45068(class_2561.method_43470(counter + " configs reload successfully"));
                                            return Command.SINGLE_SUCCESS;
                                        }))
                                .then(class_2170.method_9244("path", StringArgumentType.string())
                                        .suggests((c, b) -> class_2172.method_9265(ConfigManager.getAllPaths(), b))
                                        .executes(c -> {
                                            var path = StringArgumentType.getString(c, "path");
                                            boolean isAdmin = c.getSource().method_9259(4);
                                            
                                            if (!ConfigManager.getAllPaths().contains(path)) {
                                                c.getSource().method_9213(class_2561.method_43470("Config by path \"" + path + "\" does not exist"));
                                                return 0;
                                            }
                                            
                                            try {
                                                
                                                if (ConfigManager.isServerConfig(path)) {
                                                    if (isAdmin) {
                                                        ConfigManager.reload(path);
                                                        ConfigManager.syncConfig(path, c.getSource().method_9211());
                                                    } else
                                                        c.getSource().method_9213(
                                                                class_2561.method_43470("You have not permission to reload config."));
                                                } else {
                                                    ConfigManager.reload(path);
                                                }
                                                
                                                c.getSource().method_45068(class_2561.method_43470("Config with path \"" + path + "\" has been reloaded successfully"));
                                            } catch (RuntimeException e) {
                                                e.printStackTrace();
                                                c.getSource().method_9213(class_2561.method_43470("Error occurs while reloading config by path ")
                                                        .method_10852(class_2561.method_43470("\"" + path + "\"")));
                                                
                                                return 0;
                                            }
    
                                            return Command.SINGLE_SUCCESS;
                                        })))
                )
        );
    }
    
}
