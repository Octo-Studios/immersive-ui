package it.hurts.octostudios.octolib.module.config.util;

import com.mojang.datafixers.util.Pair;
import it.hurts.octostudios.octolib.OctoLib;
import it.hurts.octostudios.octolib.module.config.ConfigManager;
import it.hurts.octostudios.octolib.module.config.impl.OctoConfig;
import lombok.experimental.UtilityClass;
import org.apache.logging.log4j.util.Cast;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;

@UtilityClass
public class ConfigUtils {
    
    public static void registerFieldConfig(Field field, String dir) {
        field.setAccessible(true);
        try {
            var value = field.get(null);
            
            if (value == null)
                OctoLib.LOGGER.warn("Failed to load config in " + dir + " directory: config is null.");
            
            for (var a : field.getAnnotations()) {
                var fabric = ConfigManager.getConfigFactory(a.annotationType());
                
                if (fabric == null) {
                    OctoLib.LOGGER.warn("Unsupported annotation {} for config initialization.", a);
                    continue;
                }
                
                var octoConfig = fabric.getFirst().create(Cast.cast(a), value);
                var name = fabric.getSecond().getName(Cast.cast(a), value);
                
                String location = dir + "/" + name;
                ConfigManager.registerConfig(location, octoConfig);
            }
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
    
}
