package it.hurts.octostudios.octolib.module.config.network;

import dev.architectury.networking.NetworkManager;
import it.hurts.octostudios.octolib.OctoLib;
import it.hurts.octostudios.octolib.module.config.ConfigManager;
import it.hurts.octostudios.octolib.module.network.Packet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class SyncConfigPacket extends Packet {
    public static final class_8710.class_9154<SyncConfigPacket> TYPE =
            Packet.createType(OctoLib.MODID, "config_sync");
    public static final class_9139<class_9129, SyncConfigPacket> STREAM_CODEC =
            Packet.createCodec(SyncConfigPacket::write, SyncConfigPacket::new);

    private final String configPath;
    private final String configFile;

    public SyncConfigPacket(class_9129 buf) {
        this.configPath = buf.method_19772();
        this.configFile = buf.method_19772();
    }
    
    public SyncConfigPacket(String configPath) {
        this.configPath = configPath;
        this.configFile = ConfigManager.saveAsString(configPath);
    }
    
    public void write(class_9129 buf) {
        buf.method_10814(configPath);
        buf.method_10814(configFile);
    }

    @Override
    @Environment(EnvType.CLIENT)
    protected void handleClient(NetworkManager.PacketContext packetContext) {
        ConfigManager.reloadStringConfig(configFile, configPath, false);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
