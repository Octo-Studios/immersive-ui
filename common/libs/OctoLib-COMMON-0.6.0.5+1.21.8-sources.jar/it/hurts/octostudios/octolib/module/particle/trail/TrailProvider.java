package it.hurts.octostudios.octolib.module.particle.trail;

import it.hurts.octostudios.octolib.module.particle.OctoRenderManager;
import it.hurts.octostudios.octolib.module.particle.RenderProvider;
import it.hurts.octostudios.octolib.util.ColorUtils;
import it.hurts.octostudios.octolib.util.TesselatorUtils;
import it.hurts.octostudios.octolib.util.VectorUtils;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_638;
import org.joml.Matrix4f;

import static it.hurts.octostudios.octolib.util.TesselatorUtils.TRAIL_RENDER_TYPE;
import static it.hurts.octostudios.octolib.util.VectorUtils.Y_VEC;

import ;
import D;
import I;

public abstract class TrailProvider implements RenderProvider<TrailProvider, TrailBuffer> {
    @Override
    public TrailBuffer createBuffer() {
        return new DefaultTrailBuffer<>(getTrailMaxLength());
    }

    @Override
    public boolean shouldRender(TrailBuffer buffer) {
        return isTrailAlive() || (!disappearAfterDeath() && buffer.size() != 0);
    }

    @Override
    public class_243 getRenderPosition(float partialTick) {
        return getTrailPosition(partialTick);
    }

    public abstract class_243 getTrailPosition(float partialTick);

    @Override
    @Deprecated
    public double getRenderDistance() {
        return getTrailRenderDistance();
    }

    public double getTrailRenderDistance() {
        return 64;
    }

    @Override
    @Deprecated
    public int getUpdateFrequency() {
        return getTrailUpdateFrequency();
    }

    public abstract int getTrailUpdateFrequency();

    public abstract boolean isTrailAlive();

    public boolean isTrailGrowing() {
        return true;
    }

    public boolean disappearAfterDeath() {
        return false;
    }

    public abstract int getTrailMaxLength();

    public abstract int getTrailFadeInColor();

    public abstract int getTrailFadeOutColor();

    public abstract double getTrailScale();

    public int getTrailInterpolationPoints() {
        return 1;
    }

    public List<class_243> getTrailRenderPositions(List<class_243> points, float pTicks) {
        return points;
    }

    @Override
    @Deprecated
    public void render(float pTicks, class_4587 poseStack, class_4588 consumer) {
        class_638 world = class_310.method_1551().field_1687;
        if (world == null) return;

        class_243 matrixTranslation = this.getRenderPosition(pTicks);
        long time = world.method_8510();
        int segments = this.getTrailMaxLength();

        if (segments <= 0 || this.getTrailUpdateFrequency() <= 0) return;

        List<class_243> partialPoses = new ArrayList<>();
        float partial = (time % this.getTrailUpdateFrequency()) + pTicks;

        TrailBuffer buffer = OctoRenderManager.getOrCreateBuffer(this);
        if (buffer == null) return;

        List<class_243> points = new ArrayList<>();
        if (this.isTrailAlive()) points.add(new class_243(0, 0, 0));

        for (class_243 vec3 : buffer) {
            points.add(vec3.method_1020(matrixTranslation));
        }

        points = this.getTrailRenderPositions(points, pTicks);

        if (points.size() > 2) {
            for (int i = 0; i < points.size() - 1; i++) {
                class_243 p0 = i == 0 ? points.getFirst() : points.get(i - 1);
                class_243 p1 = points.get(i);
                class_243 p2 = points.get(i + 1);
                class_243 p3 = i == points.size() - 2 ? points.getLast() : points.get(i + 2);

                partialPoses.add(p1);
                int interpolationPoints = Math.max(1, this.getTrailInterpolationPoints() + 1);
                for (float f = 1f / interpolationPoints; f < 1; f += 1f / interpolationPoints) {
                    partialPoses.add(VectorUtils.catmullromVec(f, p0, p1, p2, p3));
                }
            }
            partialPoses.add(points.getLast());
        } else {
            partialPoses.addAll(points);
        }

        if (points.size() > 1 && this.getTrailMaxLength() + 1 == points.size()) {
            int i = partialPoses.size() - 1;
            class_243 adjustment = partialPoses.get(i - 1).method_1020(partialPoses.get(i))
                    .method_1021(partial / (double) this.getTrailUpdateFrequency() * this.getTrailInterpolationPoints());
            partialPoses.set(i, partialPoses.get(i).method_1019(adjustment));
        }

        if (partialPoses.size() < 2) return;

        partialPoses = partialPoses.stream().filter(Objects::nonNull).toList();

        if (partialPoses.size() < 2)
            return;

        var crossVecs = new class_243[partialPoses.size()][3];

        for (var i = 1; i < partialPoses.size(); i++) {
            var pos1 = partialPoses.get(i - 1);
            var pos2 = partialPoses.get(i);

            if (pos1 == null || pos2 == null) continue;

            var vec1 = pos2.method_1020(pos1);
            var vec1n = vec1.method_1029();

            var perpendicular1 = vec1n.method_1036(Y_VEC).method_1029();

            var scale = this.getTrailScale() * (1.0 - (double) i / (partialPoses.size() - 1)) + 0.005;

            crossVecs[i - 1][0] = perpendicular1.method_1021(scale);
            crossVecs[i - 1][1] = VectorUtils.rotate(crossVecs[i - 1][0], vec1n, 120);
            crossVecs[i - 1][2] = VectorUtils.rotate(crossVecs[i - 1][0], vec1n, -120);
        }

        var color1 = new Color(this.getTrailFadeInColor(), true);
        var color2 = new Color(this.getTrailFadeOutColor(), true);

        poseStack.method_22903();

        var matrix4f = poseStack.method_23760().method_23761();

        for (var i = 0; i < partialPoses.size() - 1; i++) {
            var pos1 = partialPoses.get(i);
            var pos2 = partialPoses.get(i + 1);

            if (pos1 == null || pos2 == null || crossVecs[i][0] == null || crossVecs[i][1] == null || crossVecs[i + 1][0] == null || crossVecs[i + 1][1] == null)
                continue;

            var tip1 = pos1.method_1019(crossVecs[i][0]);
            var base1Left = pos1.method_1019(crossVecs[i][2]);
            var base1Right = pos1.method_1019(crossVecs[i][1]);

            var tip2 = pos2.method_1019(crossVecs[i + 1][0]);
            var base2Left = pos2.method_1019(crossVecs[i + 1][2]);
            var base2Right = pos2.method_1019(crossVecs[i + 1][1]);

            var c1 = ColorUtils.blend(color1, color2, i / (float) (partialPoses.size() - 1));
            var c2 = ColorUtils.blend(color1, color2, (i + 1) / (float) (partialPoses.size() - 1));

            TesselatorUtils.drawQuadGradient(consumer, matrix4f,
                    (float) base2Left.field_1352, (float) base2Left.field_1351, (float) base2Left.field_1350,
                    (float) base1Left.field_1352, (float) base1Left.field_1351, (float) base1Left.field_1350,
                    (float) tip1.field_1352, (float) tip1.field_1351, (float) tip1.field_1350,
                    (float) tip2.field_1352, (float) tip2.field_1351, (float) tip2.field_1350, c2, c1);

            TesselatorUtils.drawQuadGradient(consumer, matrix4f,
                    (float) tip2.field_1352, (float) tip2.field_1351, (float) tip2.field_1350,
                    (float) tip1.field_1352, (float) tip1.field_1351, (float) tip1.field_1350,
                    (float) base1Right.field_1352, (float) base1Right.field_1351, (float) base1Right.field_1350,
                    (float) base2Right.field_1352, (float) base2Right.field_1351, (float) base2Right.field_1350,
                    c2, c1);

            TesselatorUtils.drawQuadGradient(consumer, matrix4f,
                    (float) base2Right.field_1352, (float) base2Right.field_1351, (float) base2Right.field_1350,
                    (float) base1Right.field_1352, (float) base1Right.field_1351, (float) base1Right.field_1350,
                    (float) base1Left.field_1352, (float) base1Left.field_1351, (float) base1Left.field_1350,
                    (float) base2Left.field_1352, (float) base2Left.field_1351, (float) base2Left.field_1350,
                    c2, c1);
        }

        poseStack.method_22909();
    }
}