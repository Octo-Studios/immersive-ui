package it.hurts.octostudios.octolib.util;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.PolygonMode;
import com.mojang.blaze3d.vertex.VertexFormat;
import it.hurts.octostudios.octolib.OctoLib;
import org.joml.Matrix4f;

import java.awt.Color;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_4588;
import net.minecraft.class_4668;

import static net.minecraft.class_10799.field_60125;

public class TesselatorUtils {

    public static final RenderPipeline TRAIL_PIPELINE = RenderPipeline.builder(field_60125)
            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
            .withBlend(BlendFunction.LIGHTNING)
            .withColorWrite(true)
            .withPolygonMode(PolygonMode.FILL)
            .withVertexShader("core/position_color")
            .withFragmentShader("core/position_color")
            .withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_27382)
            .withLocation(class_2960.method_60655(OctoLib.MODID, "trail"))
            .build();

    public static final class_1921 TRAIL_RENDER_TYPE = class_1921.method_24048("octoparticle_trail", 256, TRAIL_PIPELINE,
            class_1921.class_4688.method_23598()
                    .method_23610(class_4668.class_4678.field_21358)
                    .method_23617(false));
    
    public static void drawFullQuadWithColor(class_4588 tes, Matrix4f matrix4f, float pos1X, float pos1Y, float pos1Z, float pos2X,
                                             float pos2Y, float pos2Z, float pos3X, float pos3Y, float pos3Z, float pos4X, float pos4Y,
                                             float pos4Z, Color color) {
        
        if (matrix4f != null) {
            tes.method_22918(matrix4f, pos1X, pos1Y, pos1Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            tes.method_22918(matrix4f, pos2X, pos2Y, pos2Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            tes.method_22918(matrix4f, pos3X, pos3Y, pos3Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            tes.method_22918(matrix4f, pos4X, pos4Y, pos4Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            
            tes.method_22918(matrix4f, pos4X, pos4Y, pos4Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            tes.method_22918(matrix4f, pos3X, pos3Y, pos3Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            tes.method_22918(matrix4f, pos2X, pos2Y, pos2Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            tes.method_22918(matrix4f, pos1X, pos1Y, pos1Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
        } else {
            tes.method_22912(pos1X, pos1Y, pos1Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            tes.method_22912(pos2X, pos2Y, pos2Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            tes.method_22912(pos3X, pos3Y, pos3Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            tes.method_22912(pos4X, pos4Y, pos4Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            
            tes.method_22912(pos4X, pos4Y, pos4Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            tes.method_22912(pos3X, pos3Y, pos3Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            tes.method_22912(pos2X, pos2Y, pos2Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
            tes.method_22912(pos1X, pos1Y, pos1Z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
        }
    }

    /* public static void drawQuad(BufferBuilder tes, IIcon icon, double pos1X, double pos1Y, double pos1Z, double pos2X,
                                double pos2Y, double pos2Z, double pos3X, double pos3Y, double pos3Z, double pos4X, double pos4Y,
                                double pos4Z) {

        float maxU = icon.getMaxU();
        float maxV = icon.getMaxV();
        float minU = icon.getMinU();
        float minV = icon.getMinV();

        tes.addVertexWithUV(pos1X, pos1Y, pos1Z, maxU, maxV);
        tes.addVertexWithUV(pos2X, pos2Y, pos2Z, maxU, minV);
        tes.addVertexWithUV(pos3X, pos3Y, pos3Z, minU, minV);
        tes.addVertexWithUV(pos4X, pos4Y, pos4Z, minU, maxV);

    } */
    
    public static void drawQuadGradient(class_4588 tes, Matrix4f matrix4f, float pos1X, float pos1Y, float pos1Z, float pos2X,
                                        float pos2Y, float pos2Z, float pos3X, float pos3Y, float pos3Z, float pos4X, float pos4Y,
                                        float pos4Z, Color color1, Color color2) {
        
        if (matrix4f != null) {
            tes.method_22918(matrix4f,  pos4X,  pos4Y,  pos4Z).method_1336(color1.getRed(), color1.getGreen(), color1.getBlue(), color1.getAlpha());
            tes.method_22918(matrix4f,  pos1X,  pos1Y,  pos1Z).method_1336(color1.getRed(), color1.getGreen(), color1.getBlue(), color1.getAlpha());
            tes.method_22918(matrix4f,  pos2X,  pos2Y,  pos2Z).method_1336(color2.getRed(), color2.getGreen(), color2.getBlue(), color2.getAlpha());
            tes.method_22918(matrix4f,  pos3X,  pos3Y,  pos3Z).method_1336(color2.getRed(), color2.getGreen(), color2.getBlue(), color2.getAlpha());
        } else {
            tes.method_22912(pos4X, pos4Y, pos4Z).method_1336(color1.getRed(), color1.getGreen(), color1.getBlue(), color1.getAlpha());
            tes.method_22912(pos1X, pos1Y, pos1Z).method_1336(color1.getRed(), color1.getGreen(), color1.getBlue(), color1.getAlpha());
            tes.method_22912(pos2X, pos2Y, pos2Z).method_1336(color2.getRed(), color2.getGreen(), color2.getBlue(), color2.getAlpha());
            tes.method_22912(pos3X, pos3Y, pos3Z).method_1336(color2.getRed(), color2.getGreen(), color2.getBlue(), color2.getAlpha());
        }
    }
    
}