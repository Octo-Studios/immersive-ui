package it.hurts.octostudios.octolib.util;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_3532;
import org.joml.Vector2f;

public class VectorUtils {

    public static final class_243 X_VEC = new class_243(1, 0, 0);
    public static final class_243 Y_VEC = new class_243(0, 1, 0);
    public static final class_243 Z_VEC = new class_243(0, 0, 1);

    public static void saveToNBT(String name, class_2487 tag, class_243 vec3) {
        class_2487 tag1 = new class_2487();
        tag1.method_10549("x", vec3.field_1352);
        tag1.method_10549("y", vec3.field_1351);
        tag1.method_10549("z", vec3.field_1350);
        tag.method_10566(name, tag1);
    }

    public static class_243 loadFromNBT(String name, class_2487 tag) {
        class_2487 tag1 = tag.method_10562(name).get();
        return new class_243(
                tag1.method_10574("x").get(),
                tag1.method_10574("y").get(),
                tag1.method_10574("z").get()
        );
    }

    public static class_243 parse(class_2338 pos) {
        return new class_243(pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    public static class_243 parse(class_1297 entity) {
        return new class_243(entity.method_19538().field_1352, entity.method_19538().field_1351, entity.method_19538().field_1350);
    }
    
    public static class_243 catmullromVec(float f, class_243 v1, class_243 v2, class_243 v3, class_243 v4) {
        return new class_243(
                class_3532.method_41303(f, (float) v1.field_1352, (float) v2.field_1352, (float) v3.field_1352, (float) v4.field_1352),
                class_3532.method_41303(f, (float) v1.field_1351, (float) v2.field_1351, (float) v3.field_1351, (float) v4.field_1351),
                class_3532.method_41303(f, (float) v1.field_1350, (float) v2.field_1350, (float) v3.field_1350, (float) v4.field_1350)
        );
    }

    public static class_243 rotate(class_243 v, class_243 axis, double angle) {
        angle = Math.toRadians(angle);
        double sinAngle = Math.sin(angle);
        double cosAngle = Math.cos(angle);
        double k = 1 - cosAngle;
        double a = axis.field_1352;
        double b = axis.field_1351;
        double c = axis.field_1350;
        double m00 = a * a * k + cosAngle;
        double m01 = a * b * k - c * sinAngle;
        double m02 = a * c * k + b * sinAngle;
        double m10 = b * a * k + c * sinAngle;
        double m11 = b * b * k + cosAngle;
        double m12 = b * c * k - a * sinAngle;
        double m20 = c * a * k - b * sinAngle;
        double m21 = c * b * k + a * sinAngle;
        double m22 = c * c * k + cosAngle;
        double x = v.field_1352 * m00 + v.field_1351 * m01 + v.field_1350 * m02;
        double y = v.field_1352 * m10 + v.field_1351 * m11 + v.field_1350 * m12;
        double z = v.field_1352 * m20 + v.field_1351 * m21 + v.field_1350 * m22;
        return new class_243(x, y, z);
    }

    public static Vector2f rotate(Vector2f vec, float rotDegrees) {
        float radians = (float) Math.toRadians(rotDegrees);

        float cos = (float) Math.cos(radians);
        float sin = (float) Math.sin(radians);

        float newX = vec.x * cos - vec.y * sin;
        float newY = vec.x * sin + vec.y * cos;

        return new Vector2f(newX, newY);
    }
}
