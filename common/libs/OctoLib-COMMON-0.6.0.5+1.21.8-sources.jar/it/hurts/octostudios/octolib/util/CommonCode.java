package it.hurts.octostudios.octolib.util;

import it.hurts.octostudios.octolib.module.particle.OctoRenderManager;
import it.hurts.octostudios.octolib.module.particle.RenderProvider;
import net.fabricmc.loader.impl.lib.sat4j.core.Vec;
import net.minecraft.class_243;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9779;
import org.jetbrains.annotations.Nullable;

public class CommonCode {
    public static void applyShake(class_332 guiGraphics, float partialTick) {

    }

    public static void renderTrails(class_4184 camera, class_4597.class_4598 consumers, class_4587 poseStack, class_9779 deltaTracker) {
        class_243 vec3 = camera.method_19326();
        double d = vec3.method_10216();
        double e = vec3.method_10214();
        double g = vec3.method_10215();

        class_4588 consumer = consumers.getBuffer(TesselatorUtils.TRAIL_RENDER_TYPE);
        float f = deltaTracker.method_60637(false);

        for (RenderProvider trail : OctoRenderManager.getProviders()) {
            class_243 position = trail.getRenderPosition(f);
            poseStack.method_22903();
            poseStack.method_22904(position.field_1352 - d, position.field_1351 - e, position.field_1350 - g);
            trail.render(f, poseStack, consumer);
            poseStack.method_22909();
        }

        consumers.method_22994(TesselatorUtils.TRAIL_RENDER_TYPE);
    }
}
