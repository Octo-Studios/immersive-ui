package it.hurts.octostudios.octolib.util;

import java.awt.Color;
import net.minecraft.class_3532;

public class ColorUtils {

    public static Color blend(Color a, Color b, double t) {
        t = class_3532.method_15350(t, 0, 1);

        int aRed = a.getRed();
        int aGreen = a.getGreen();
        int aBlue = a.getBlue();
        int aAlpha = a.getAlpha();

        int bRed = b.getRed();
        int bGreen = b.getGreen();
        int bBlue = b.getBlue();
        int bAlpha = b.getAlpha();

        int blendedRed = class_3532.method_48781((float) t, aRed, bRed);
        int blendedGreen = class_3532.method_48781((float) t, aGreen, bGreen);
        int blendedBlue = class_3532.method_48781((float) t, aBlue, bBlue);
        int blendedAlpha = class_3532.method_48781((float) t, aAlpha, bAlpha);

        return new Color(blendedRed, blendedGreen, blendedBlue, blendedAlpha);
    }

    public static int lerpInt(int colorStart, int colorEnd, float t) {
        t = class_3532.method_15363(t, 0, 1);

        int aStart = (colorStart >> 24) & 0xFF;
        int rStart = (colorStart >> 16) & 0xFF;
        int gStart = (colorStart >> 8) & 0xFF;
        int bStart = colorStart & 0xFF;

        int aEnd = (colorEnd >> 24) & 0xFF;
        int rEnd = (colorEnd >> 16) & 0xFF;
        int gEnd = (colorEnd >> 8) & 0xFF;
        int bEnd = colorEnd & 0xFF;

        int a = (int)(aStart + t * (aEnd - aStart));
        int r = (int)(rStart + t * (rEnd - rStart));
        int g = (int)(gStart + t * (gEnd - gStart));
        int b = (int)(bStart + t * (bEnd - bStart));

        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int clamp(int value) {
        return class_3532.method_15340(value, 0, 255);
    }
}
