package it.hurts.octostudios.octolib.util;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import it.hurts.octostudios.octolib.mixin.GuiGraphicsAccessor;
import net.minecraft.class_1921;
import net.minecraft.class_241;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4668;
import net.minecraft.client.renderer.*;
import org.joml.*;

import java.awt.geom.Point2D;
import java.lang.Math;
import java.util.function.BiFunction;

public class RenderUtils {
    public static final BiFunction<RenderPipeline, class_2960, class_1921> OCTO_GUI = (pipeline, rl) -> class_1921.method_24048("octogui", 1536, pipeline,
            class_1921.class_4688.method_23598()
                    .method_34577(new class_4668.class_4683(rl, false))
                    .method_23617(false));

    public static class_241 toScreenCoords(Matrix3x2f matrix, double x, double y) {
        Matrix3x2f inverse = new Matrix3x2f(matrix);
        inverse.invert();
        return toViewportCoords(inverse, x, y);
    }

    public static class_241 toViewportCoords(Matrix3x2f matrix, double x, double y) {
        Vector3f vec = new Vector3f((float) x, (float) y, 1.0f);
        vec = matrix.transform(vec);
        return new class_241(vec.x(), vec.y());
    }

    private boolean isPointInQuad(double x, double y, Point2D[] quad) {
        // we divide the quad into two triangles and check if the point is in either one
        return pointInTriangle(x, y, quad[0], quad[1], quad[2]) ||
                pointInTriangle(x, y, quad[0], quad[2], quad[3]);
    }

    private boolean pointInTriangle(double px, double py, Point2D a, Point2D b, Point2D c) {
        double area = 0.5 * (-b.getY() * c.getX() + a.getY() * (-b.getX() + c.getX()) +
                a.getX() * (b.getY() - c.getY()) + b.getX() * c.getY());

        double sign = area < 0 ? -1 : 1;

        double s = (a.getY() * c.getX() - a.getX() * c.getY() + (c.getY() - a.getY()) * px + (a.getX() - c.getX()) * py) * sign;
        double t = (a.getX() * b.getY() - a.getY() * b.getX() + (a.getY() - b.getY()) * px + (b.getX() - a.getX()) * py) * sign;

        return s >= 0 && t >= 0 && (s + t) <= 2 * area * sign;
    }

    public static void renderTextureFromCenter(RenderPipeline pipeline, class_2960 texture, class_332 guiGraphics, float centerX, float centerY, float width, float height, float scale, int color, float zOffset) {
        renderTextureFromCenter(pipeline, texture, guiGraphics, centerX, centerY, 0f, 0f, (int) width, (int) height, width, height, scale, color);
    }

    public static void renderTextureFromCenter(
            RenderPipeline pipeline,
            class_2960 texture,
            class_332 guiGraphics,
            float centerX,
            float centerY,
            float texOffX,
            float texOffY,
            int texWidth,                // changed to int as requested
            int texHeight,               // changed to int as requested
            float width,
            float height,
            float scale,
            int color
    ) {
        // compute scaled width/height (kept as floats)
        float scaledWidth = width * scale;
        float scaledHeight = height * scale;

        // top-left position so the texture is rendered centered at (centerX, centerY)
        float x = centerX - scaledWidth * 0.5f;
        float y = centerY - scaledHeight * 0.5f;

        // texture coordinates in texels (keep as floats to preserve precision)
        float u = texOffX;
        float v = texOffY;

        // region size in texels (what portion of the texture atlas to draw)
        int regionW = Math.round(width);   // original region width/height (unscaled)
        int regionH = Math.round(height);

        guiGraphics.method_25291(pipeline, texture, (int) x, (int) y, u, v, regionW, regionH, texWidth, texHeight, color);
    }

    public static void renderTilingTexture(RenderPipeline pipeline, class_2960 texture, class_332 guiGraphics, float x, float y, float texOffX, float texOffY,
                                           float texWidth, float texHeight, float width, float height,
                                           int color, boolean tileHorizontally, boolean tileVertically) {
        float uStart = texOffX / texWidth;
        float vStart = texOffY / texHeight;
        float uRange = tileHorizontally ? (width / texWidth) : 1.0f;
        float vRange = tileVertically ? (height / texHeight) : 1.0f;
        float uEnd = uStart + uRange;
        float vEnd = vStart + vRange;

        Matrix3x2fStack matrix = guiGraphics.method_51448();
        matrix.pushMatrix();
        matrix.translate(x, y);

//        builder.addVertex(0f, height*16, 100).setUv(uStart, vEnd).setColor(color)
//                .addVertex(width, height*16, 100).setUv(uEnd, vEnd).setColor(color)
//                .addVertex(width, 0f, 100).setUv(uEnd, vStart).setColor(color)
//                .addVertex(0f, 0f, 100).setUv(uStart, vStart).setColor(color);

        GuiGraphicsAccessor accessor = (GuiGraphicsAccessor) guiGraphics;
        accessor.innerBlitAccessor(pipeline, texture, 0, (int) width, 0, (int) height, uStart, uEnd, vStart, vEnd, color);

        //guiGraphics.renderOutline(0,0, (int) width, (int) height,color);
        matrix.popMatrix();


        //bufferSource.endBatch();
    }
}
