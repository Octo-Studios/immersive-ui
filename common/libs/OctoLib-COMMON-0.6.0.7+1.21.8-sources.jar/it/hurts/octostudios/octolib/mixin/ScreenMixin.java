package it.hurts.octostudios.octolib.mixin;

import it.hurts.octostudios.octolib.client.particle.ParticleSystem;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_437.class)
public class ScreenMixin {
//    @Inject(method = "render", at = @At("RETURN"))
//    private void beforeRender(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
//        Screen screen = (Screen) (Object) this;
//        if (screen instanceof AbstractContainerScreen<?>) {
//            return;
//        }
//
//        ParticleSystem.renderScreenParticles(screen, guiGraphics, Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(false));
//    }
}
