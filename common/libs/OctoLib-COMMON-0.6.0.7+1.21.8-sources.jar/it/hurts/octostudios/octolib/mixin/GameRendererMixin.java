package it.hurts.octostudios.octolib.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import it.hurts.octostudios.octolib.client.particle.ParticleSystem;
import it.hurts.octostudios.octolib.module.particle.OctoRenderManager;
import it.hurts.octostudios.octolib.util.DeltaTimeTracker;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class GameRendererMixin {
    @Shadow @Final private class_310 minecraft;

    @Inject(method = "render", at = @At("HEAD"))
    private void injectHead(class_9779 deltaTracker, boolean renderLevel, CallbackInfo ci) {
        DeltaTimeTracker.updateDeltaTime();
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;isGameLoadFinished()Z"))
    private void renderTick(class_9779 deltaTracker, boolean renderLevel, CallbackInfo ci) {
        OctoRenderManager.clientRenderTick();
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;renderWithTooltip(Lnet/minecraft/client/gui/GuiGraphics;IIF)V", shift = At.Shift.AFTER))
    private void renderScreenParticles(class_9779 deltaTracker, boolean renderLevel, CallbackInfo ci, @Local class_332 guiGraphics) {
        ParticleSystem.renderScreenParticles(minecraft.field_1755, guiGraphics, deltaTracker.method_60637(false));
    }
}
