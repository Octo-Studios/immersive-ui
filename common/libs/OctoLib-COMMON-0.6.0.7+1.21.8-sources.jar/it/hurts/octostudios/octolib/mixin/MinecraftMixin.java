package it.hurts.octostudios.octolib.mixin;

import it.hurts.octostudios.octolib.client.animation.TweenSystem;
import it.hurts.octostudios.octolib.client.particle.ParticleSystem;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftMixin {
    @Inject(method = "runTick", at = @At(value = "TAIL"))
    private void injectDeltaNanos(boolean renderLevel, CallbackInfo ci) {
        TweenSystem.RenderThreadExecutor.executeAll();
    }

    @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;tick(Z)V"))
    private void tick(CallbackInfo ci) {
        ParticleSystem.tick();
    }
}
