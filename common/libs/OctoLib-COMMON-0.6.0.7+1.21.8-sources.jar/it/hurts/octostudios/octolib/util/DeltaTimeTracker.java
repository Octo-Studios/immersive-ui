package it.hurts.octostudios.octolib.util;

import lombok.Getter;
import net.minecraft.class_156;

public class DeltaTimeTracker {
    private static long lastTimeNanos = -1L;
    @Getter
    private static double deltaSeconds = 0.0;

    public static void updateDeltaTime() {
        long now = class_156.method_648();
        if (lastTimeNanos != -1L) {
            deltaSeconds = (now - lastTimeNanos) / 1_000_000_000.0;
        }

        lastTimeNanos = now;
    }
}
